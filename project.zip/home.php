




<?php


$today = date("Y-m-d");

print "Today is: $today.";

?>


  


<?php
$account_name = "usbank";
$company = NULL;

ini_set('diplay_errors', 'on');
error_reporting(e_all);


include 'functions.php';

$acct_tab = " SELECT  id, acct_name FROM account";
$acct_array = array();
$capture_acct_col = "acct_name";
$bank_tab = " SELECT  id, bank_name FROM banks";
$bank_array = array();
$capture_bank_col = "bank_name";


/*Get values for the selection menus*/

dropValues($bank_tab, $bank_array, $capture_bank_col );


dropValues($acct_tab, $acct_array, $capture_acct_col );


/*source: http://php.net/manual/en/mysqli.quickstart.prepared-statements.php*/
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","dohertki-db","gvBKWgFuUOM2piV6","dohertki-db");

if($mysqli->connect_errno){
    echo "connection error". $mysqli->connect_errno . " " . $mysqli->connect_error;
}         


if (!($stmt = $mysqli->prepare(

/*    select  d.name_d, d.desc_d, d.date_d, d.amount ,sum(d.amount) from account a */
  "  select  d.name_d, d.desc_d, date_format(d.date_d, '%d/%m/%Y'), d.amount from account a
    INNER JOIN transactions t ON t.acct_id = a.id  
    INNER JOIN debits d ON  d.id = t.exp_id ORDER BY d.date_d ASC;"))) {
    echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
}




if (!$stmt->execute()) {
    echo "Execute failed: (" . $mysqli->errno . ") " . $mysqli->error;
}


if (!$stmt->bind_result( $company, $desc_d, $date_d, $amount_d)){
    echo "Binding output parameters failed: (". $stmt->errno  . ") " . $stmt->error;}



/*
    SELECT d.id, d.name_d, d.desc_d, d.date_d, d.amount FROM account a

 */
?>
<!DOCTYPE html>

<html>
  <head>
    <title> Ledger</title>
    <link href="css/style.css" type="text/css" rel="stylesheet"/>  
  </head>
  <body>



<!-- Tab menu based on source: http://www.htmldog.com/techniques/tabs/ -->

    <div id="header">
        <h1>Ledger page</h1>
        <ul>
            <li id="selected"><a href="home.php">Ledger</a></li>
            <li ><a href="account.php">Accounts</a></li>
            <li><a href="expenses.php">Expenses</a></li>
            <li><a href="incomes.php">Incomes</a></li>
            <li ><a href="banks.php">Banks</a></li>
        </ul>
    </div>

    <div id="spacebar">
    </div>


    <div id="Ledger" class="tabs">
        <h3> :</h3>
    <table>
      <tbody>
      <th>Date </th>
      <th>Payer/Payee</th>
      <th> Description</th>
      <th> Debit</th>
      <th> Balance</th>


         <?php

        while ($stmt->fetch()){
            printf("<tr><td> %s </td><td> %s</td><td> %s </td><td> %s </td></tr> ", $date_d, $company, $desc_d, money_format('%n', $amount_d ));
        
        
        }



?>


      </tbody>

    </table>
    </div>




    <div>
      <form method="post"  action="insert_led.php">
        <fieldset>
          <legend> Create Transaction</legend>

            Bank Name:
            <select name="banks">

            <?php

            foreach($bank_array as $k => $id){
            ?>

            <option value="<?php echo $k ; ?> "><?php echo $id; ?></option>

            <?php

            }
            ?>
            </select>
           <br/>
              
            Account:
            <select name="account">

            <?php

            foreach($acct_array as $k => $id){
            ?>

            <option value="<?php echo $k ; ?> "><?php echo $id; ?></option>

            <?php
            }
            ?>
            </select>
           <br/>

            Type:             
            <select name="banks">
              <option value="1">Credit</option>
              <option value="0">Dedit</option>

            </select>
           <br/>
             Payer/Payee
             <input type="text" name="bank_name" maxlength="30"/>
           <br/> 

            Description:
             <input type="text" name="bank_add" maxlength="30"/>
           <br/>
            

            Amount:
             <input type="text" name="bank_phone" maxlength="30"/>
           <br/>    
        



        </fieldset>
        <input type="submit" name="add_tran" value="Add Transaction" />
       
      </form>    









  </body>




</html>


<?php

        $stmt->close();

?>







